<?php

include_once ('connection.php');
$masa = $_POST["masa"];
$koraci =  $_POST["koraci"];
$korisnik = $_POST["idKorisnik"];
$datum = date("Y-m-d");
$sql = "INSERT INTO masa (id_korisnik, masa, datum) VALUES ('".$korisnik."' ,'".$masa."','".$datum."');";
if ($conn->query($sql) == TRUE){
  $sql2 = "INSERT INTO kretanje (id_korisnik, broj_koraka, datum) VALUES ('".$korisnik."' ,'".$koraci."','".$datum."');";
  if ($conn->query($sql2) == TRUE){
    echo "Uspješno!";
  }
  else {
    echo "Neuspjeh";
  }
}else{
  echo "Neuspjeh";
}

?>
