-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 16, 2019 at 01:25 PM
-- Server version: 5.7.23
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fitness`
--

-- --------------------------------------------------------

--
-- Table structure for table `korisnik`
--

DROP TABLE IF EXISTS `korisnik`;
CREATE TABLE IF NOT EXISTS `korisnik` (
  `id_korisnik` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_croatian_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_croatian_ci NOT NULL,
  `ime` varchar(255) COLLATE utf8_croatian_ci NOT NULL,
  `prezime` varchar(255) COLLATE utf8_croatian_ci NOT NULL,
  `visina` int(11) NOT NULL,
  `masa` int(11) NOT NULL,
  `email_id` varchar(255) COLLATE utf8_croatian_ci NOT NULL,
  PRIMARY KEY (`id_korisnik`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_croatian_ci;

--
-- Dumping data for table `korisnik`
--

INSERT INTO `korisnik` (`id_korisnik`, `username`, `password`, `ime`, `prezime`, `visina`, `masa`, `email_id`) VALUES
(1, 'test', 'test', 'pero', 'peric', 180, 90, 'jpirjac@gmail.com'),
(3, 'vinko', 'vinko', 'vinko', 'vinko', 190, 110, ''),
(5, 'jure', 'jure', 'Jure', 'Juric', 170, 70, ''),
(9, 'k', 'k', 'k', 'kj', 44, 4, ''),
(10, 'ele', 'l', 'Elena', 'Jelenič', 190, 80, ''),
(11, 'j', 'hgf', 'hgf', 'ghf', 5, 4, ''),
(12, 'hgf', 'hgf', 'hgf', 'hgf', 54, 32, '');

-- --------------------------------------------------------

--
-- Table structure for table `korisnik_trening`
--

DROP TABLE IF EXISTS `korisnik_trening`;
CREATE TABLE IF NOT EXISTS `korisnik_trening` (
  `id_korisnik` int(11) NOT NULL,
  `id_trening` int(11) NOT NULL AUTO_INCREMENT,
  `datum` date NOT NULL,
  `trajanje` int(11) NOT NULL,
  PRIMARY KEY (`id_korisnik`,`id_trening`,`datum`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_croatian_ci;

--
-- Dumping data for table `korisnik_trening`
--

INSERT INTO `korisnik_trening` (`id_korisnik`, `id_trening`, `datum`, `trajanje`) VALUES
(1, 3, '2019-08-17', 20),
(1, 1, '2018-10-10', 20),
(1, 2, '2019-08-23', 15),
(1, 4, '2019-08-25', 0),
(1, 5, '2019-08-25', 0),
(1, 6, '2019-08-25', 0),
(1, 7, '2019-08-25', 0),
(1, 8, '2019-08-25', 0),
(1, 1, '2019-08-26', 20),
(10, 1, '2019-08-26', 20),
(1, 9, '2019-09-08', 0),
(1, 3, '2019-09-07', 20),
(1, 10, '2019-09-08', 0),
(1, 11, '2019-09-08', 0),
(1, 12, '2019-09-08', 0),
(1, 13, '2019-09-08', 0),
(1, 14, '2019-09-08', 0),
(1, 2, '2019-09-10', 15),
(1, 15, '2019-09-15', 0),
(1, 16, '2019-09-15', 0),
(1, 17, '2019-09-15', 0),
(1, 18, '2019-09-15', 0),
(1, 19, '2019-09-15', 0),
(1, 1, '2019-09-16', 20);

-- --------------------------------------------------------

--
-- Table structure for table `kretanje`
--

DROP TABLE IF EXISTS `kretanje`;
CREATE TABLE IF NOT EXISTS `kretanje` (
  `id_korisnik` int(11) NOT NULL,
  `datum` date NOT NULL,
  `broj_koraka` int(11) NOT NULL,
  `udaljenost` float DEFAULT NULL,
  `visina-razlika` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_korisnik`,`datum`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_croatian_ci;

--
-- Dumping data for table `kretanje`
--

INSERT INTO `kretanje` (`id_korisnik`, `datum`, `broj_koraka`, `udaljenost`, `visina-razlika`) VALUES
(1, '2019-04-26', 10000, 1000, 15),
(1, '2019-04-25', 15000, 1500, 6),
(1, '2019-04-22', 15000, 1500, 6),
(1, '2019-04-18', 5000, 500, 6),
(1, '2019-04-27', 6100, NULL, NULL),
(1, '2019-05-01', 20000, NULL, NULL),
(5, '2019-05-01', 15000, NULL, NULL),
(5, '2019-04-26', 10000, NULL, NULL),
(5, '2019-04-27', 12000, NULL, NULL),
(5, '2019-04-28', 1000, NULL, NULL),
(5, '2019-04-30', 20000, NULL, NULL),
(1, '2019-05-02', 5000, NULL, NULL),
(5, '2019-05-02', 5000, NULL, NULL),
(1, '2019-08-17', 70000, NULL, NULL),
(1, '2019-08-23', 8000, 5961.6, NULL),
(10, '2019-08-26', 5000, 3933, NULL),
(1, '2019-09-05', 21, 15.6492, NULL),
(1, '2019-09-07', 2, 1.4904, NULL),
(1, '2019-09-08', 1, 0.7452, NULL),
(1, '2019-09-15', 21, 15.6492, NULL),
(1, '2019-09-16', 900, 670.68, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `masa`
--

DROP TABLE IF EXISTS `masa`;
CREATE TABLE IF NOT EXISTS `masa` (
  `id_korisnik` int(11) NOT NULL,
  `datum` date NOT NULL,
  `masa` int(11) NOT NULL,
  PRIMARY KEY (`id_korisnik`,`datum`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_croatian_ci;

--
-- Dumping data for table `masa`
--

INSERT INTO `masa` (`id_korisnik`, `datum`, `masa`) VALUES
(1, '2019-04-26', 79),
(1, '2019-04-25', 81),
(1, '2019-04-24', 82),
(1, '2019-04-20', 85),
(1, '2019-04-18', 87),
(1, '2019-04-10', 90),
(1, '2019-04-27', 81),
(1, '2019-05-01', 80),
(5, '2019-05-01', 72),
(5, '2019-04-28', 70),
(5, '2019-04-30', 71),
(1, '2019-05-02', 78),
(5, '2019-05-02', 70),
(1, '2019-08-17', 70),
(1, '2019-08-23', 80),
(10, '2019-08-26', 69),
(1, '2019-09-05', 21),
(1, '2019-09-07', 1),
(1, '2019-09-08', 21),
(1, '2019-09-15', 21),
(1, '2019-09-16', 110);

-- --------------------------------------------------------

--
-- Table structure for table `trening`
--

DROP TABLE IF EXISTS `trening`;
CREATE TABLE IF NOT EXISTS `trening` (
  `id_treninga` int(11) NOT NULL AUTO_INCREMENT,
  `opis` text COLLATE utf8_croatian_ci NOT NULL,
  `vrsta` text COLLATE utf8_croatian_ci NOT NULL,
  `trajanje` int(11) NOT NULL,
  PRIMARY KEY (`id_treninga`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_croatian_ci;

--
-- Dumping data for table `trening`
--

INSERT INTO `trening` (`id_treninga`, `opis`, `vrsta`, `trajanje`) VALUES
(1, '1. Bench press <br>\r\nLeđima legnite na ravnu klupu, stopala su čvrsto smještena na podu. Šipku primite u širini ramena tako da vam čelo dođe točno ispod nje. Polako spuštajte šipku dok Vam ne dotakne prsa, a potom ju na isti način podignite prema gore dok ruke ne budu \r\nispružene. \r\nUčinite bar 5 setova s 12 ponavljanja\r\n<br><br>\r\n2. Sklekovi <br>\r\nOkrenite se licem prema podlozi. Oslonite se na dlanove, a tijelo držite tako da vam je kralježnica ravna.\r\nSavijajući podlaktice spustite se prsima što više podu i istim putem vratite se natrag.\r\nUčinite bar 5 setova s 12 ponavljanja.\r\n<br><br>\r\n3. Potisak na ravnoj klupi s bučicama <br>\r\nIsta tehnika kao kod bench pressa.\r\nLeđima legnite na ravnu klupu, stopala su čvrsto smještena na podu. Utege polako spuštajte dok Vam ne dotaknu prsa, a potom ih na isti način podignite prema gore dok ruke ne budu \r\nispružene. \r\nUčinite bar 5 setova s 12 ponavljanja.\r\n', 'Vježbe za prsa', 20),
(2, '1. Čučanj <br>\r\nOvu vježbu možete raditi na klasični način bez utega uz 100 ponavljanja, ili ukoliko imate utege 5 setova s 15 ponavljanja.\r\nIspravljenih leđa savijajte koljena sve dok vam natkoljenice ne budu paralelne s podom. Kada se spustite, vratite se u početni položaj potiskivanjem tijela prema gore iz peta.\r\n<br><br>\r\n2. Čučanj s jednom nogom <br>\r\nIz početne pozicije spuštamo se u čučanj tako da je lijeva noga ispružena ispred tijela i vraćamo se u početni položaj.\r\nUčinite 5 setova po 5 ponavljanja. Ukoliko ste početnik možete si potpomoći rukama za održavanje ravnoteže.\r\nUkoliko imate snage ponovite vježbe još jednom', 'Vježbe za noge', 15),
(3, '1. Zgibovi <br>\r\nUhvatite se za zidnu šipku pod većom širinom od ramena. Ispružite laktove tako da Vam tijelo visi. Dižite se prema gore sve dok ne pređete šipku bradom. Zategnite leđa. Lagano se spuštajte do početnog položaja. \r\n5 setova po 5-12 ponavljanja\r\n<br><br>\r\n2. Mrtvo dizanje <br>\r\nStanite pored šipke tako da Vam stopala budu razmaknuta otprilike u širini ramena. Primite šipku u širini ramena i držite leđa uspravno. Savijte koljena dok vam natkoljenice ne dođu u paralelne s podom. Iz tog položaja dižite se prema gore ravnajući noge sve dok vam tijelo ne bude potpuno uspravljeno, vratite se u početnu poziciju.\r\n5 setova po 12 ponavljanja\r\n<br><br>\r\n3. Jednoručno veslanje sa utezima <br>\r\nUhvatite uteg s jednom rukom. Slobodnu ruku i koljeno postavite na klupu i držite leđa tijekom cijele vježbe uspravnima i zategnutima. Podižite bućicu vertikalno tako da lakat podignete što više možete. Spustite uteg u početni položaj.\r\n5 setova po 12 ponavljanja', 'Vježbe za leđa', 20);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
