<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <script type="text/javaScript">
      function validateEmail(email) {
        var re = /\S+@\S+\.\S+/;
        return re.test(email);
      }
			function provjera() {
        var $result = $("#result");
         var email = $("#email").val();
          if (validateEmail(email)) {
            return true;
            $result.text(email + " nije valjan. Upišite točan email :(");
            $result.css("color", "red");
          }
			    else{
              $result.text(email + " nije valjan. Upišite točan email :(");
              $result.css("color", "red");
              return false;
					}
			//when it return true- your form will  submit and will  redirect
			// (actually its a part of submit) id you have mentioned in action
			}
		</script>
    <center>
    <form method="post" name="myForm" onSubmit="return provjera();">
      <h1>Zaboravili ste lozinku?</h1>
      <br><br>
      Email:
      <input id="#email" type="text" name="username">
      <input type="submit" value="Pošalji">
    </form>
    <p id="#result"></p>
    </center>
  </body>
</html>

<?php

if (isset($_POST["username"])){
  // Please specify your Mail Server - Example: mail.example.com.
  ini_set("SMTP","smtp.gmail.com");

  // Please specify an SMTP Number 25 and 8889 are valid SMTP Ports.
  ini_set("smtp_port","465");

  // Please specify the return address to use
  ini_set('sendmail_from', 'example@YourDomain.com');
  mail("jpirjac@gmail.com","My subject","blabla");
}
?>
