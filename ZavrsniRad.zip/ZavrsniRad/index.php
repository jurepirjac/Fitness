<!DOCTYPE html>

<?php
  if ($_SESSION['loggedin']) {
  if(!isset($_SESSION))
  {
      session_start();
  }

  include_once ('connection.php');
  $username = $_SESSION['name'];
  $password = $_SESSION['password'];
  $sql = "SELECT id_korisnik FROM korisnik WHERE username = '".$username."' AND password ='".$password."'";
  $result = $conn->query($sql);
  if ($result->num_rows == 1){
    $row = $result->fetch_assoc();
    $korisnik = $row["id_korisnik"];
  }

  else{
    echo '<p>Pogreska</p>';
  }
?>

<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>JUX FITNESS</title>

  <!-- Font Awesome Icons -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet">
  <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>

  <!-- Plugin CSS -->
  <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

  <!-- Theme CSS - Includes Bootstrap -->
  <link href="css/creative.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="#page-top">JUX FITNESS</a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto my-2 my-lg-0">
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#about">O nama</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#services">Usluge</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#unos">Unos podataka</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#trening">Trening</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#grafovi">Grafovi napretka</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#trenutni_podaci">Vaši podaci</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="logout.php">Odjava</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Masthead -->
  <header class="masthead">
    <div class="container h-100">
      <div class="row h-100 align-items-center justify-content-center text-center">
        <div class="col-lg-10 align-self-end">
          <h1 class="text-uppercase text-white font-weight-bold">JUX FITNESS - Vaš pomoćnik u ispunjenju Vaših ciljeva</h1>
          <hr class="divider my-4">
        </div>
        <div class="col-lg-8 align-self-baseline">
          <p class="text-white-75 font-weight-light mb-5">Poboljšajte svoje zdravlje praćenjem vaših aktivnosti</p>
          <a class="btn btn-primary btn-xl js-scroll-trigger" href="#about">Saznajte više</a>
        </div>
      </div>
    </div>
  </header>

  <!-- About Section -->
  <section class="page-section bg-primary" id="about">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8 text-center">
          <h2 class="text-white mt-0">Imamo sve što Vam je potrebno za ispunjenje Vaših ciljeva prema zdravijem tijelu</h2>
          <hr class="divider light my-4">
          <p class="text-white-50 mb-4">Pratite Vaše korake, treninge i uz intuitivne grafove vidite kako se Vaši kilogrami gube</p>
          <a class="btn btn-light btn-xl js-scroll-trigger" href="#services">Prikaz usluga</a>
        </div>
      </div>
    </div>
  </section>

  <!-- Services Section -->
  <section class="page-section" id="services">
    <div class="container">
      <h2 class="text-center mt-0">Na Vašem raspolaganju</h2>
      <hr class="divider my-4">
      <div class="row">
        <div class="col-lg-3 col-md-6 text-center">
          <div class="mt-5">
            <a class="nav-link js-scroll-trigger" href="#trening"><i class="fas fa-4x fa-dumbbell text-primary mb-4"></i></a>
            <h3 class="h4 mb-2">Treninzi</h3>
            <p class="text-muted mb-0">Odrađujte treninge i pratite Vaš napredak</p>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 text-center">
          <div class="mt-5">
            <a class="nav-link js-scroll-trigger" href="#unos"><i class="fas fa-4x fa-running text-primary mb-4"></i></a>
            <h3 class="h4 mb-2">Koraci</h3>
            <p class="text-muted mb-0">Pratite Vaše korake i svaki dan pokušajte ostvariti što bolji uspjeh</p>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 text-center">
          <div class="mt-5">
            <a class="nav-link js-scroll-trigger" href="#unos"><i class="fas fa-4x fa-weight text-primary mb-4"></i></a>
            <h3 class="h4 mb-2">Masa</h3>
            <p class="text-muted mb-0">Redovito pratite masu kako bi došli do željene kilaže</p>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 text-center">
          <div class="mt-5">
            <a class="nav-link js-scroll-trigger" href="#grafovi"><i class="fas fa-4x fa-chart-line text-primary mb-4"></i></a>
            <h3 class="h4 mb-2">Grafovi</h3>
            <p class="text-muted mb-0">Uz intuitivne grafove lako vidite vaš napredak</p>
          </div>
        </div>
      </div>
      <br><br>
      <div class="row justify-content-center">
         <a class="btn btn-light btn-xl js-scroll-trigger" href="#unos">Ažurirajte Vaše podatke</a>
      </div>
    </div>
  </section>


<script type="text/javascript">
  function provjera(){
    if(document.myForm.koraci.value == '' || document.myForm.masa.value == ''){
      alert('Molimo unesite sve podatke (masu i korake)!');
      return false;
    }
    else if(parseInt(document.myForm.koraci.value) < 0){
      alert('Koraci mora biti pozitivan broj!');
      return false;
    }
    else if (parseInt(document.myForm.masa.value) < 20 || parseInt(document.myForm.masa.value) > 200) {
      alert('Masa mora biti u intervalu [20, 200]!');
      return false;
    }
    else {
      return true;
    }
  }
</script>
  <!-- Unos podataka -->
  <section class="page-section bg-light" id="unos">
    <form action = "submit.php" name="myForm" method="get" onSubmit="return provjera();">
      <div class="container">
        <p class="h2 mb-2" style="text-align:center;">Unos podataka</p>
        <hr class="divider my-4">
        <div class="row justify-content-center">
          <div class="col-lg-3 col-md-6 text-center">
            <div class="mt-5">
              <i class="fas fa-4x fa-running text-primary mb-4"></i>
              <h3 class="h4 mb-2">Koraci</h3>
              <input type="number" class="form-control" placeholder="Unesite korake:" id="koraci" name="koraci">
            </div>
          </div>
          <div class="col-lg-3 col-md-6 text-center">
            <div class="mt-5">
              <i class="fas fa-4x fa-weight text-primary mb-4"></i>
              <h3 class="h4 mb-2">Masa</h3>
              <input type="number" class="form-control" id="masa" name="masa" placeholder="Unesite trenutnu masu:">
              <input type="hidden" id="custId" name="korisnik" value="<?php echo $korisnik ?>">
            </div>
          </div>
        </div>
      </div>
      <br><br>
      <input type="hidden" id="idKorisnik" name="idKorisnik" value="<?php echo $korisnik ?>">
      <div class="row justify-content-center">
        <button type="submit" class="btn btn-secondary btn-xl">Pošaljite podatke</button>
      </div>
    </form>

    <!-- obrada podataka -->
    <?php
      if (isset($_GET["masa"]) && !empty($_GET["masa"]) && isset($_GET["koraci"]) && !empty($_GET["koraci"])){
        $masa = $_GET["masa"];
        $koraci =  $_GET["koraci"];
        $korisnik = $_GET["idKorisnik"];
        $sql = "SELECT visina FROM korisnik WHERE id_korisnik = '".$korisnik."'";
        $result = $conn->query($sql);
        if ($result->num_rows == 1){
          while($row = $result->fetch_assoc()) {
            $duljina_koraka = (int)$row["visina"] * 0.414 / 100;
          }
        }
        else{
          echo "pogreška </p>";
        }
        $udaljenost = $koraci * $duljina_koraka;
        $datum = date("Y-m-d");
        $sql = "INSERT INTO masa (id_korisnik, masa, datum) VALUES ('".$korisnik."' ,'".$masa."','".$datum."');";
          if ($conn->query($sql) == TRUE){
            $sql2 = "INSERT INTO kretanje (id_korisnik, broj_koraka, datum, udaljenost) VALUES ('".$korisnik."' ,'".$koraci."','".$datum."','".$udaljenost."');";
            if ($conn->query($sql2) == TRUE){
              echo "<script>confirm('Uspješno poslani podaci');</script>";
              echo "<script>window.location.hash = '#grafovi'</script>";
              echo "<script>window.location.reload(true);</script>";
            }
            else {
              echo "<script>alert('Pogreška!');</script>";
            }
          }else{
            echo "<script>alert('Podaci za danas već unijeti!');</script>";
            echo "<script>window.location.href = './#unos'</script>";
          }
      }
    ?>

    <br><br>
    <div class="row justify-content-center">
       <a class="btn btn-light btn-xl js-scroll-trigger btn-dark" href="#trening">Odradite dostupni trening:</a>
    </div>
  </section>

  <!-- Trening -->
  <?php
  if(date('l') === 'Monday' || date('l') === 'Thursday'){
    $sql = "SELECT vrsta, opis, trajanje FROM trening WHERE id_treninga = 1";
    $result = $conn->query($sql);
    if ($result->num_rows == 1){
      while($row = $result->fetch_assoc()) {
        $vrsta = $row["vrsta"];
        $opis = $row["opis"];
        $trajanje = $row["trajanje"];
        $id_trening = 1;
      }
      echo $row["prezime"]."</p>";
    }
    else{
      echo "pogreška </p>";
    }
  }
  else if(date('l') === 'Tuesday' || date('l') === 'Friday'){
    $sql = "SELECT vrsta, opis, trajanje FROM trening WHERE id_treninga = 2";
    $result = $conn->query($sql);
    if ($result->num_rows == 1){
      while($row = $result->fetch_assoc()) {
        $vrsta = $row["vrsta"];
        $opis = $row["opis"];
        $trajanje = $row["trajanje"];
        $id_trening = 2;
      }
      echo $row["prezime"]."</p>";
    }
    else{
      echo "pogreška </p>";
    }
  }
  else if(date('l') === 'Wednesday' || date('l') === 'Saturday'){
    $sql = "SELECT vrsta, opis, trajanje FROM trening WHERE id_treninga = 3";
    $result = $conn->query($sql);
    if ($result->num_rows == 1){
      while($row = $result->fetch_assoc()) {
        $vrsta = $row["vrsta"];
        $opis = $row["opis"];
        $trajanje = $row["trajanje"];
        $id_trening = 3;
      }
      echo $row["prezime"]."</p>";
    }
    else{
      echo "pogreška </p>";
    }
  }
  else if(date('l') === 'Sunday'){
    $vrsta = "Nedjelja!";
    $opis = "Vrijeme odmora";
    $trajanje = "0";
    $id_trening = 0;
  }
  ?>
  <section class="page-section" id="trening">
    <div class="container">
      <p class="h2 mb-2" style="text-align:center;">Trening</p>
      <hr class="divider my-4">
       <br>
      <div class="row justify-content-center">
        <div class="col-lg-6 mb-4">
          <div class="card h-100">
            <a href="#"><img class="card-img-top" src="img/bg-masthead.jpg" alt=""></a>
            <div class="card-body">
              <h4 class="card-title">
                <p><?php echo $vrsta; ?>, trajanje: <u><?php echo $trajanje; ?> minuta </u>  </p>
              </h4>
              <p class="card-text text-muted mb-0">
                <?php echo $opis; ?>
              </p>
            </div>
          </div>
        </div>
      </div>
      <div class="row justify-content-center">
       <a class="btn btn-light btn-xl js-scroll-trigger" id="#spremi" onclick="trening()">Odradio trening!</a>
       <script  type="text/javascript">
       function trening(){
         <?php
         $date =  date('Y-m-d');
         $sql = "INSERT INTO korisnik_trening(id_korisnik, id_trening, datum, trajanje) VALUES ('".$korisnik."','".$id_trening."',STR_TO_DATE('".$date."', '%Y-%m-%d'),'".$trajanje."')";
         if ($conn->query($sql) == TRUE){
            ?>
            confirm('Uspješno poslan podatak o određenom treningu');
            window.location.href = './#trening';
            <?php
         }
         else{
           ?>//if(alert('Već ste odradili trening za danas!')) else
           confirm('Već ste odradili trening za danas!');
           window.location.href = './#trening';
           <?php
         }
         ?>
       }
       </script>
    </div>
    <br><br>
      <div class="row justify-content-center">
       <a class="btn btn-light btn-xl js-scroll-trigger" href="#grafovi">Vidite napredak na grafovima</a>
    </div>
    </div>
  </section>


  <!-- Grafovi -->
  <section class="page-section bg-light" id="grafovi">
    <p class="h1" style="text-align:center;">Grafovi</p>
    <hr class="divider my-4"><br>
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-6 col-sm text-center">
            <p class="h2">Masa</p> <br>
            <canvas id="lineChart"></canvas>
        </div>
        <div class="col-lg-6 col-sm text-center">
            <p class="h2">Koraci</p> <br>
            <canvas id="myChart2"></canvas>
        </div>
      </div>
    </div>
  </section>

  <section class="page-section" id="trenutni_podaci">
    <div class="container">
      <h2 class="text-center mt-0">Vaši trenutni podatci</h2>
      <hr class="divider my-4">
      <div class="row">
        <div class="col-lg-2 col-md-6 text-center">
          <div class="mt-5">
            <i class="fas fa-4x fa-user text-primary mb-4"></i>
            <h3 class="h4 mb-2">Ime</h3>
            <p class="text-muted mb-0">
            <?php
            $sql = "SELECT ime FROM korisnik WHERE username = '".$username."' AND password ='".$password."'";
            $result = $conn->query($sql);
            if ($result->num_rows == 1){
              $row = $result->fetch_assoc();
              echo $row["ime"]."</p>";}
            else{
              echo "pogreška </p>";
            } ?>
          </div>
        </div>
        <div class="col-lg-2 col-md-6 text-center">
          <div class="mt-5">
            <i class="fas fa-4x fa-user-alt text-primary mb-4"></i>
            <h3 class="h4 mb-2">Prezime</h3>
            <p class="text-muted mb-0">
              <?php
              $sql = "SELECT prezime FROM korisnik WHERE username = '".$username."' AND password ='".$password."'";
              $result = $conn->query($sql);
              if ($result->num_rows == 1){
                $row = $result->fetch_assoc();
                echo $row["prezime"]."</p>";}
              else{
                echo "pogreška </p>";
              } ?>
          </div>
        </div>
        <div class="col-lg-2 col-md-6 text-center">
          <div class="mt-5">
            <i class="fas fa-4x fa-running text-primary mb-4"></i>
            <h3 class="h4 mb-2">Zadnja prijeđena udaljenost</h3>
            <p class="text-muted mb-0">
              <?php
              try{
              $sql = "SELECT udaljenost FROM kretanje WHERE id_korisnik = '".$korisnik."' ORDER BY datum DESC";
              $result = $conn->query($sql);
              if ($result->num_rows > 0){
                $row = $result->fetch_assoc();
                echo $row["udaljenost"]." metara</p>";}
              }catch (Exception $e){
                echo "pogreška: ". $e->getMessage()." </p>";
              } ?>
          </div>
        </div>
        <div class="col-lg-2 col-md-6 text-center">
          <div class="mt-5">
            <i class="fas fa-4x fa-shoe-prints text-primary mb-4"></i>
            <h3 class="h4 mb-2">Zadnji broj prijeđenih koraka</h3>
            <p class="text-muted mb-0">
              <?php
              $sql = "SELECT broj_koraka FROM kretanje WHERE id_korisnik = '".$korisnik."' ORDER BY datum DESC";
              $result = $conn->query($sql);
              if ($result->num_rows > 0){
                $row = $result->fetch_assoc();
                echo $row["broj_koraka"]." koraka</p>";}
              else{
              } ?>
          </div>
        </div>
        <div class="col-lg-2 col-md-6 text-center">
          <div class="mt-5">
            <i class="fas fa-4x fa-weight text-primary mb-4"></i>
            <h3 class="h4 mb-2">Trenutna masa</h3>
            <p class="text-muted mb-0">
              <?php
              try{
              $sql = "SELECT masa FROM masa WHERE id_korisnik = '".$korisnik."' ORDER BY datum DESC";
              $result = $conn->query($sql);
              if ($result->num_rows > 0){
                $row = $result->fetch_assoc();
                echo $row["masa"]." kg</p>";}
              } catch (Exception $e){
                  echo "pogreška: ". $e->getMessage()." </p>";
              } ?>
          </div>
        </div>
        <div class="col-lg-2 col-md-6 text-center">
          <div class="mt-5">
            <i class="fas fa-4x fa-male text-primary mb-4"></i>
            <h3 class="h4 mb-2">Visina</h3>
            <p class="text-muted mb-0">
              <?php
              $sql = "SELECT visina FROM korisnik WHERE username = '".$username."' AND password ='".$password."'";
              $result = $conn->query($sql);
              if ($result->num_rows == 1){
                $row = $result->fetch_assoc();
                echo $row["visina"]."cm</p>";}
              else{
                echo "pogreška </p>";
              } ?>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer class="py-5 bg-light">
    <div class="container">
      <div class="small text-center text-dark">Copyright &copy; 2019 - Start Bootstrap</div>
    </div>
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

  <!-- Custom scripts for this template -->
  <script src="js/creative.min.js"></script>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.js"></script>


  <?php
  $datumi = array();
  $mase = array();
  $sql = "SELECT datum, masa FROM masa WHERE id_korisnik = '".$korisnik."' ORDER BY datum ASC";
  $result = $conn->query($sql);
  if ($result->num_rows > 0){
    while($row = $result->fetch_assoc()) {
      $datumi[] = $row["datum"];
      $mase[] = $row["masa"];
    }
  }

  $datumi2 = array();
  $koraci = array();
  $sql2 = "SELECT datum, broj_koraka FROM kretanje WHERE id_korisnik = '".$korisnik."' ORDER BY datum ASC";
  $result = $conn->query($sql2);
  if ($result->num_rows > 0){
    while($row = $result->fetch_assoc()) {
      $datumi2[] = $row["datum"];
      $koraci[] = $row["broj_koraka"];
    }
  }
  ?>



  <script>
      //line
      var ctxL = document.getElementById("lineChart").getContext('2d');
      var myLineChart = new Chart(ctxL, {
        type: 'line',
        data: {
          labels: <?php echo json_encode($datumi); ?>,
          datasets: [
            {
              label: "Sve mase",
              data: <?php echo json_encode($mase); ?>,
              backgroundColor: [
                'rgba(0, 137, 132, .2)',
              ],
              borderColor: [
                'rgb(0,0,0)',
              ],
              borderWidth: 2
            }
          ]
        },
        options: {
          responsive: true
        },
      });

    </script>

  <script  type="text/javascript">
    var ctx = document.getElementById("myChart2").getContext('2d');
    var myChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: <?php echo json_encode($datumi2); ?>,
        datasets: [{
          label: 'koraci',
          data: <?php echo json_encode($koraci); ?>,
          backgroundColor: 'rgb(255,127,80)',
          borderColor: 'rgb(0,0,0)',
          borderWidth: 1
        }]
      },
      options: {
        scales: {
          yAxes: [{
            ticks: {
              beginAtZero: true
            }
          }]
        }
      }
    });
  </script>

</body>

</html>

<?php
}
else {
  header('Location: login/');
}
?>
