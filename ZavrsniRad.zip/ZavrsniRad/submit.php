<?php
  include_once ('connection.php');
  if (isset($_GET["masa"]) && !empty($_GET["masa"]) && isset($_GET["koraci"]) && !empty($_GET["koraci"])){
  $masa = $_GET["masa"];
  $koraci =  $_GET["koraci"];
  $korisnik = $_GET["idKorisnik"];
  $sql = "SELECT visina FROM korisnik WHERE id_korisnik = '".$korisnik."'";
  $result = $conn->query($sql);
  if ($result->num_rows == 1){
    while($row = $result->fetch_assoc()) {
      $duljina_koraka = (int)$row["visina"] * 0.414 / 100;
    }
  }
  else{
    echo "pogreška </p>";
  }
  $udaljenost = $koraci * $duljina_koraka;
  $datum = date("Y-m-d");
  $sql = "INSERT INTO masa (id_korisnik, masa, datum) VALUES ('".$korisnik."' ,'".$masa."','".$datum."');";
    if ($conn->query($sql) == TRUE){
      $sql2 = "INSERT INTO kretanje (id_korisnik, broj_koraka, datum, udaljenost) VALUES ('".$korisnik."' ,'".$koraci."','".$datum."','".$udaljenost."');";
      if ($conn->query($sql2) == TRUE){
        echo "<script>alert('Uspješno poslani podaci');</script>";
        echo "<script>window.location.href = './#grafovi'</script>";
      }
      else {
        echo "<script>alert('Pogreška!');</script>";
      }
    }else{
      echo "<script>alert('Podaci za danas već unijeti!');</script>";
      echo "<script>window.location.href = './#unos'</script>";
    }
}
?>
