<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>JuxFitness registracija</title>
		<style>
		.login-form {
			width: 300px;
			margin: 0 auto;
			font-family: Tahoma, Geneva, sans-serif;
		}
		.login-form h1 {
			text-align: center;
			color: #4d4d4d;
			font-size: 24px;
			padding: 20px 0 20px 0;
		}
		.login-form input[type="password"],
		.login-form input[type="text"] {
			width: 100%;
			padding: 15px;
			border: 1px solid #dddddd;
			margin-bottom: 15px;
			box-sizing:border-box;
		}
		.login-form input[type="submit"] {
			width: 100%;
			padding: 15px;
			background-color: #f4623a;
			border: 0;
			box-sizing: border-box;
			cursor: pointer;
			font-weight: bold;
			color: #ffffff;
		}
		</style>
	</head>
	<body>
		<div class="login-form">
			<h1>Registracija detalji</h1>
			<form method="post">
				<input type="text" name="username" placeholder="Unesite username">
				<input type="password" name="password" placeholder="Unesite password">
				<input type="text" name="ime" placeholder="Unesite Vaše ime">
				<input type="text" name="prezime" placeholder="Unesite Vaše prezime">
				<input type="text" name="visina" placeholder="Unesite visinu">
				<input type="text" name="masa" placeholder="Unesite Vašu trenutnu masu">
				<input type="submit" value="Registracija">
			</form>

			<br>

			<?php
			if (!empty($_POST["username"]) && !empty($_POST["password"]) && !empty($_POST["ime"]) && !empty($_POST["prezime"]) && !empty($_POST["visina"]) && !empty($_POST["masa"])){
			$servername = "localhost";
			$username = "root";
			$password = "";
			$dbname = "fitness";

			// Create connection
			$conn = new mysqli($servername, $username, $password, $dbname);

			// Check connection
			if ($conn->connect_error) {
			    die("Connection failed: " . $conn->connect_error);
			}
			// Prepare our SQL
			if ($stmt = $conn->prepare('INSERT INTO korisnik (id_korisnik, username, password, ime, prezime, visina, masa) VALUES (null,?,?,?,?,?,?)')) {
			  // Bind parameters (s = string, i = int, b = blob, etc), hash the password using the PHP password_hash function.
			  $stmt->bind_param('ssssss', $_POST['username'], $_POST['password'], $_POST['ime'], $_POST['prezime'], $_POST['visina'], $_POST['masa']);
			  $stmt->execute();
			  $stmt->store_result();
			  // Store the result so we can check if the account exists in the database.

				?>
					<script type="text/javascript">
					alert("Uspješna registracija!");
					window.location.href = "../login/";
					</script>
				<?php
				//echo "<script>alert('Uspješna registracija');</script>";
			  //header('Refresh: 5; Location: ../login/');
			  $stmt->close();
			} else {
			  echo 'Could not prepare statement!';
			}
			}
			else{
				echo ('Molimo unesite sve tražene podatke');
			}
			?>
		</div>
	</body>
</html>
