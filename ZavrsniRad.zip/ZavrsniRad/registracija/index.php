<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>JuxFitness registracija</title>
		<style>
		.login-form {
			width: 300px;
			margin: 0 auto;
			font-family: Tahoma, Geneva, sans-serif;
		}
		.login-form h1 {
			text-align: center;
			color: #4d4d4d;
			font-size: 24px;
			padding: 20px 0 20px 0;
		}
		.login-form input[type="password"],
		.login-form input[type="text"] {
			width: 100%;
			padding: 15px;
			border: 1px solid #dddddd;
			margin-bottom: 15px;
			box-sizing:border-box;
		}
		.login-form input[type="submit"] {
			width: 100%;
			padding: 15px;
			background-color: #f4623a;
			border: 0;
			box-sizing: border-box;
			cursor: pointer;
			font-weight: bold;
			color: #ffffff;
		}
		input[type=number]{
    width: 295px;
		height: 40px;
}
		</style>
	</head>
	<body>
		<script type="text/javaScript">
			function provjera() {
			    if (document.myForm.username.value == '' || document.myForm.username.value == '' || document.myForm.password.value == '' || document.myForm.ime.value == '' || document.myForm.prezime.value == '' || document.myForm.visina.value == '' || document.myForm.masa.value == ''){
							alert('Molimo unesite sve podatke');
							return false;
			        //when it return false - your form will not submit and will not redirect too
					}
					else if ((parseInt(document.myForm.masa.value) < 20 || parseInt(document.myForm.masa.value) > 200) && (parseInt(document.myForm.visina.value) < 100 || parseInt(document.myForm.visina.value) > 300)) {
							alert('Molimo unesite točnu masu između 20 i 200 kilograma i visinu između 100 i 300 centimetara');
							document.myForm.masa.setAttribute("style", "border: 1px solid red;");
							document.myForm.visina.setAttribute("style", "border: 1px solid red;");
							return false;
					}
					else if (parseInt(document.myForm.visina.value) < 100 || parseInt(document.myForm.visina.value) > 300) {
							alert('Molimo unesite točnu visinu između 100 i 300 centimetara');
							document.myForm.visina.setAttribute("style", "border: 1px solid red;");
							return false;
					}
					else if (parseInt(document.myForm.masa.value) < 20 || parseInt(document.myForm.masa.value) > 200) {
							alert('Molimo unesite točnu masu između 20 i 200 kilograma');
							document.myForm.masa.setAttribute("style", "border: 1px solid red;");
							return false;
					}
					else if (document.myForm.username.value != '') {

					}
			    else{
			        return true;
					}
			//when it return true- your form will  submit and will  redirect
			// (actually its a part of submit) id you have mentioned in action
			}
		</script>
		<div class="login-form">
			<h1>Registracija detalji</h1>
			<center><p id="#alert" style="color:red">Molimo unesite sve tražene podatke</p></center>
			<form method="post" name="myForm" onSubmit="return provjera();">
				<input type="text" name="username" placeholder="Unesite username">
				<input type="password" name="password" placeholder="Unesite password">
				<input type="text" name="ime" placeholder="Unesite Vaše ime">
				<input type="text" name="prezime" placeholder="Unesite Vaše prezime">
				<input type="number" name="visina" placeholder="Unesite visinu (u centimetrima)">
				<br><br>
				<input type="number" name="masa" placeholder="Unesite Vašu trenutnu masu (u kilogramima)">
				<br><br>
				<input type="submit" value="Registracija">
			</form>

			<br>

			<?php
			if (!empty($_POST["username"]) && !empty($_POST["password"]) && !empty($_POST["ime"]) && !empty($_POST["prezime"]) && !empty($_POST["visina"]) && !empty($_POST["masa"])){
			$servername = "localhost";
			$username = "root";
			$password = "";
			$dbname = "fitness";

			// Create connection
			$conn = new mysqli($servername, $username, $password, $dbname);
			mysqli_set_charset($conn,"utf8");

			// Check connection
			if ($conn->connect_error) {
			    die("Connection failed: " . $conn->connect_error);
			}
			// Prepare our SQL
			$sql = "SELECT username FROM korisnik WHERE username = '".$_POST['username']."'";
			$result = $conn->query($sql);
			if ($result->num_rows == 1){
				echo "<p style='color:red'>Već postoji username '".$_POST['username']."'</p>";
				echo "<script>alert('Već postoji username ".$_POST['username']."!');</script>";
				echo "<script>document.myForm.username.value='".$_POST['username']."'</script>";
				echo "<script>document.myForm.password.value='".$_POST['password']."'</script>";
				echo "<script>document.myForm.ime.value='".$_POST['ime']."'</script>";
				echo "<script>document.myForm.prezime.value='".$_POST['prezime']."'</script>";
				echo "<script>document.myForm.visina.value=".$_POST['visina']."</script>";
				echo "<script>document.myForm.masa.value=".$_POST['masa']."</script>";
				echo "<script>document.myForm.username.setAttribute('style', 'border: 1px solid red;');</script>";
			}
			else{
				if ($stmt = $conn->prepare('INSERT INTO korisnik (id_korisnik, username, password, ime, prezime, visina, masa) VALUES (null,?,?,?,?,?,?)')) {
				  // Bind parameters (s = string, i = int, b = blob, etc), hash the password using the PHP password_hash function.
				  $stmt->bind_param('ssssss', $_POST['username'], $_POST['password'], $_POST['ime'], $_POST['prezime'], $_POST['visina'], $_POST['masa']);
				  $stmt->execute();
				  $stmt->store_result();
				  // Store the result so we can check if the account exists in the database.

					?>
						<script type="text/javascript">
						alert("Uspješna registracija!");
						window.location.href = "../login/";
						</script>
					<?php
					//echo "<script>alert('Uspješna registracija');</script>";
				  //header('Refresh: 5; Location: ../login/');
				  $stmt->close();
				} else {
				  echo 'Could not prepare statement!';
				}
			}
			}

			?>
			<p>Vratite se na login page <a href="../">Login</a></p>
		</div>
	</body>
</html>
