<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>JuxFitness login</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<style>
		.login-form {
			width: 300px;
			margin: 0 auto;
			font-family: Tahoma, Geneva, sans-serif;
		}
		.login-form h1 {
			text-align: center;
			color: #4d4d4d;
			font-size: 24px;
			padding: 20px 0 20px 0;
		}
		.login-form input[type="password"],
		.login-form input[type="text"] {
			width: 100%;
			padding: 15px;
			border: 1px solid #dddddd;
			margin-bottom: 15px;
			box-sizing:border-box;
		}
		.login-form input[type="submit"] {
			width: 100%;
			padding: 15px;
			background-color: #f4623a;
			border: 0;
			box-sizing: border-box;
			cursor: pointer;
			font-weight: bold;
			color: #ffffff;
		}
		</style>
	</head>
	<body>
		<div class="login-form">
			<h1>Login detalji</h1>
			<form method="post">
				<input type="text" name="username" placeholder="Unesite username">
				<input type="password" name="password" placeholder="Unesite password">
				<input type="submit" value="Login">
			</form>

			<br>

			<?php
			if (isset($_POST["username"]) && !empty($_POST["username"]) && isset($_POST["password"]) && !empty($_POST["password"])){
			if(!isset($_SESSION))
			{
			    session_start();
			}
			$servername = "localhost";
			$username = "root";
			$password = "";
			$dbname = "fitness";

			// Create connection
			$conn = new mysqli($servername, $username, $password, $dbname);

			// Check connection
			if ($conn->connect_error) {
			    die("Connection failed: " . $conn->connect_error);
			}
			// Now we check if the data was submitted, isset will check if the data exists.
			if (!isset($_POST['username'], $_POST['password']) ) {
			  // Could not get the data that should have been sent.
			  die ('Username and/or password does not exist!');
			}
			// Prepare our SQL
			if ($stmt = $conn->prepare('SELECT password FROM korisnik WHERE username = ?')) {
			  // Bind parameters (s = string, i = int, b = blob, etc), hash the password using the PHP password_hash function.
			  $stmt->bind_param('s', $_POST['username']);
			  $stmt->execute();
			  $stmt->store_result();
			  // Store the result so we can check if the account exists in the database.
			  if ($stmt->num_rows > 0) {
			    $stmt->bind_result($password);
			    $stmt->fetch();
			    // Account exists, now we verify the password.
			    $password = password_hash($password, PASSWORD_DEFAULT);
			    if (password_verify($_POST['password'], $password)) {
			      // Verification success! User has loggedin!
			      $_SESSION['loggedin'] = TRUE;
			      $_SESSION['name'] = $_POST['username'];
						$_SESSION['password'] = $_POST['password'];
			      header('Location: ../');
			    } else {
			      echo 'Pogrešan username i/ili password!';
			    }
			  } else {
			    echo 'Pogrešan username i/ili password!!!';

			  }
			  $stmt->close();
			} else {
			  echo 'Could not prepare statement!';
			}
			}
			else{
				echo ('Molimo unesite username i password');
			}
			?>

			<p>Nemate račun? <a href="../registracija/">Registrirajte se!</a></p>
		</div>
	</body>
</html>
